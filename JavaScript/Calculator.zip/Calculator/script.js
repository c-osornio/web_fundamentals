var displayDiv = document.querySelector("#display");
displayDiv.innerText = "0";

function press(number) {

}
function clr() {
    displayDiv.innerText = "0"
}

function setOP(operator) {

}

function calculate() {
    firstValue 
    updateDisplay() {

    }
}